"""Section B of the homework: the exploration metric.

Edit this file through this ``%%writefile hw/student_metric.py`` cell, then re-run
it and ``importlib.reload(student_metric)`` (the check cell below) to pick up your
edits without restarting the kernel.
"""

from __future__ import annotations

import numpy as np


def coverage_entropy(
    visit_counts: "np.ndarray", reachable_mask: "np.ndarray"
) -> tuple[float, float]:
    """Summarise how much of the map was explored, and how evenly.

    Two scalars over the cells that *can* be reached (``reachable_mask``); cells
    outside that mask never count.

    Args:
        visit_counts: ``(N, N)`` int array -- how often each grid cell was visited.
        reachable_mask: ``(N, N)`` bool array -- the cells that count toward both
            numbers.

    Returns:
        ``(coverage, entropy_bits)``:

        * **coverage** -- the share of reachable cells visited at least once
          (``0.0`` when none, ``1.0`` when all). A breadth measure.
        * **entropy_bits** -- the Shannon entropy, in *bits*, of the visit
          distribution over the reachable cells: large when visits are spread
          evenly, small when the agent keeps revisiting a few cells. Define it as
          ``0.0`` when nothing reachable has been visited yet.
    """
    # TODO(student): coverage = visited fraction; entropy = spread of visits (bits)
    raise NotImplementedError
